# De Chauffers Event Planners website

Static site (HTML, CSS, JS). No build step, no dependencies.

## Deploy
1. Push to GitHub:
   ```
   git init
   git add .
   git commit -m "De Chauffers website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/de-chauffers-site.git
   git push -u origin main
   ```
2. Go to vercel.com, choose Add New > Project, import the repo, and click Deploy.
   Leave Framework Preset as "Other". No build command or output directory is needed.

## Edit before going live
- Phone and WhatsApp number: search for `2348166290030` and `0816 629 0030`.
- Services, FAQ answers and copy in `index.html`: make sure they match what the business really offers.
- Add real reviews, event photos and the business logo as the owner collects them.
- Replace the Google rating (4.8, 5 reviews) in `index.html` when it changes.
- Colours are the variables at the top of `styles.css`.

The quote form opens WhatsApp with the details filled in, so the owner receives leads directly with no backend.
