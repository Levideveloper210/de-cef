document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('quote-form').addEventListener('submit', function (e) {
  e.preventDefault();
  var f = new FormData(e.target);
  var msg = "Hello De Chauffers, I'd like a free quote.\n\n" +
    "Name: " + f.get('name') + "\n" +
    "Phone: " + f.get('phone') + "\n" +
    "Event: " + f.get('type') + "\n" +
    "Date: " + (f.get('date') || 'Not decided yet') + "\n" +
    "Guests: " + (f.get('guests') || 'Not sure yet') + "\n" +
    (f.get('notes') ? "\n" + f.get('notes') : "");
  window.open('https://wa.me/2348166290030?text=' + encodeURIComponent(msg), '_blank');
});
